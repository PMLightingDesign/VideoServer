# VideoServer

This was built for a specific project.

No support provided if anyone choses to use this application

https://github.com/mutschler/mt
